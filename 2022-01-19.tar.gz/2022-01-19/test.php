<?php

$image = 'https://www.baeldung.com/wp-content/uploads/2018/07/lss-course-mockup-New-1.jpg?33';
$imageData = base64_encode(file_get_contents($image));
echo '<img src="data:image/jpeg;base64,'.$imageData.'">';
?>
